# Class 9 Timetable Android App

This project wraps the supplied Maharashtra Class 9 Timetable & Study Companion HTML app in an Android WebView.

## Build the APK without a computer (GitHub Actions)

1. On GitHub, create a **new repository** (public or private).
2. Upload the contents of this ZIP to the repository's root. Make sure `.github/workflows/build-apk.yml` is included.
3. Open the repository's **Actions** tab and select **Build Class 9 Timetable APK**.
4. Tap **Run workflow** (or wait for the build to start after uploading to `main`).
5. When it finishes successfully, open that workflow run and find **Artifacts** near the bottom.
6. Download `Class9-Timetable-APK`, extract the ZIP, and you'll find `app-debug.apk`.
7. Transfer the APK to your Android phone and open it to install. Android may ask you to allow installs from that file manager/browser.

## Important
- This ZIP is the Android project, **not a precompiled APK**. This environment does not have the Android SDK/Gradle build setup needed to compile the APK directly.
- The app stores timetable, checklist, and homework data in the WebView's local storage on that device.
- The HTML currently loads Tailwind CSS, Font Awesome, and Google Fonts from online CDNs, so an internet connection is needed for those styling assets.
- For a release-ready public app, create a signed release build and review app branding/privacy before publishing.
